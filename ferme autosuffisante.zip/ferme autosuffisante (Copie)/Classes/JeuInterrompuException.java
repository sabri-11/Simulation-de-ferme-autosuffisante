package projet;

public class JeuInterrompuException extends Exception
{
	public JeuInterrompuException(String msg)
	{
		super(msg);
	}
}