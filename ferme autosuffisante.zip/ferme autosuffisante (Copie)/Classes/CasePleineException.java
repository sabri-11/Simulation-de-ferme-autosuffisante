package projet;

public class CasePleineException extends Exception
{
	public CasePleineException(String msg)
	{
		super(msg);
	}
}
