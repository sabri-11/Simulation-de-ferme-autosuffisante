package projet;

import java.io.File;

import javax.imageio.ImageIO;

public class DestructionImpossibleException extends Exception
{
	public DestructionImpossibleException(String msg)
	{
		super(msg);
	}
}
