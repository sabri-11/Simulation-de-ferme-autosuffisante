package projet;

public class ReproImpossibleException extends Exception
{
	public ReproImpossibleException(String msg)
	{
		super(msg);
	}
}
