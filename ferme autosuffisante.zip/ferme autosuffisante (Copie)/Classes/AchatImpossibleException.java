package projet;

public class AchatImpossibleException extends Exception
{
	public AchatImpossibleException(String msg)
	{
        super(msg);
    }
}
