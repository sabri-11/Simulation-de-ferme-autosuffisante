package projet;

public class EntiteNonTrouveeException extends Exception
{
	public EntiteNonTrouveeException(String msg)
	{
		super(msg);
	}
}
