package projet;

public class NiveauInsuffisantException extends Exception
{
	public NiveauInsuffisantException(String msg)
	{
		super(msg);
	}
}
