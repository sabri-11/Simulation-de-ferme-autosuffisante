package projet;

public class CapaciteDepasseeException extends Exception
{
    public CapaciteDepasseeException(String msg)
    {
        super(msg);
    }
}
