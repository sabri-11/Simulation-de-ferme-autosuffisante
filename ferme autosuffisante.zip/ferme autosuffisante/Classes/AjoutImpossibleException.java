package projet;

public class AjoutImpossibleException extends Exception
{
	public AjoutImpossibleException(String msg)
	{
		super(msg);
	}
}
