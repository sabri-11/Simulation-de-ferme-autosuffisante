package projet;

public class AucuneCaseLibreAutourException extends Exception
{
	public AucuneCaseLibreAutourException(String msg)
	{
		super(msg);
	}
}
